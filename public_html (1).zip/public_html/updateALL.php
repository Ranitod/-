<body>
<?php
$link = mysqli_connect('localhost', 'id16122503_magnit', 'j6(o$Ny6R{+/HO|P', 'id16122503_workmen');

$id=$_REQUEST['id'];
$ФИО=trim($_REQUEST['ФИО']);
$Отдел=trim($_REQUEST['Отдел']);
$Должность=$_REQUEST['Должность'];
$Телефон=trim($_REQUEST['Телефон']);
$Почта=trim($_REQUEST['Почта']);
$Логин=$_REQUEST['Логин'];
$Пароль=trim($_REQUEST['Пароль']);
$Роль=$_REQUEST['Кто'];

mysqli_query($link,"UPDATE users SET ФИО='$ФИО',Отдел='$Отдел',Должность='$Должность',Телефон='$Телефон',Почта='$Почта',Логин='$Логин', Пароль='$Пароль', Кто='$Роль' WHERE id ='".$id."'");

include("main.php");
?>
</body>
