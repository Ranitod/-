<?php
$ids =$_REQUEST['id'];
$links = mysqli_connect('localhost', 'id16122503_magnit', 'j6(o$Ny6R{+/HO|P', 'id16122503_workmen');
$query2 = mysqli_query($links, "SELECT * FROM users WHERE id =' " . $ids . " ' ");
$roee=mysqli_fetch_array($query2);
?>
<!DOCTYPE html>
<html >



<head>
<style type="text/css">
#footer
{
position: fixed; /* Фиксированное положение */
center: 0; bottom: 0; /* Внизу центр */
padding: 0px; /* Поля вокруг текста */
background: #acacac; /* Цвет фона */
color: #ffff; /* Цвет текста */
width: 100%; /* Ширина слоя */
}
</style>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="generator" content="Mobirise v4.7.2, mobirise.com">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
<link rel="shortcut icon" href="assets/images/logo4.png" type="image/x-icon">
<meta name="description" content="">
<title>Личный кабинет</title>
<link rel="stylesheet" href="assets/tether/tether.min.css">
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
<link rel="stylesheet" href="assets/datatables/data-tables.bootstrap4.min.css">
<link rel="stylesheet" href="assets/theme/css/style.css">
<link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">






</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light" style="background-color: #acacac;">
<a class="navbar-brand" href="#"><img src="assets/images/logo.png" width="287" height="53.4"></a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarNavDropdown">
<ul class="navbar-nav">
<li class="nav-item active">
<a class="nav-link" href="main.php">Главная <span class="sr-only">(current)</span></a>
</li>
<li class="nav-item dropdown">
<a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
Личный кабинет
</a>
<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
<a class="dropdown-item" href="reg.html">Добавить пользователя</a>
<a class="dropdown-item" href="change.php">Изменить данные</a>
<a class="dropdown-item" href="exit.php">Выйти</a>
</div>
</li>
</ul>
</div>
</nav>
<?php
printf("<form action='updateALL.php' method='post' name='forma'>
<fieldset>
<input type='hidden' name='id'  value='%s'><br/>
<label for='ФИО'>ФИО:</label><br/>
<input type='text' name='ФИО' size='30' value='%s'><br/>
<label for='Отдел'>Отдел:</label><br/>
<input type='text' name='Отдел' size='30' value='%s'><br/>
<label for='Должность'>Должность:</label><br/>
<input type='text' name='Должность' size='30' value='%s'><br/>
<label for='Телефон'>Телефон:</label><br/>
<input type='text' name='Телефон' size='30' value='%s'><br/>
<label for='Почта'>Почта:</label><br/>
<input type='Почта' name='Почта' size='30' value='%s'><br/>
<label for='Логин'>Логин:</label><br/>
<input type='text' name='Логин' size='30' value='%s'><br/>
<label for='Пароль'>Пароль:</label><br/>
<input type='text' name='Пароль' size='30' value='%s'><br/>
<label for='Кто'>Роль:</label><br/>
<input type='text' name='Кто' size='30' value='%s'><br/>
</fieldset>
<br/>
<fieldset>
<input id='submit' type='submit' value='Редактировать запись'><br/>
</fieldset>
</form>",$ids, $roee['ФИО'], $roee['Отдел'], $roee['Должность'], $roee['Телефон'], $roee['Почта'], $roee['Логин'], $roee['Пароль'], $roee['Кто']);
?>

<div id="footer">
<p align="center"> &copy; Официальный сайт сети «Магнит». АО «Тандер» </p>
</div>



<section class="engine"><a href="https://mobirise.me/p">website templates free download</a></section><script src="assets/web/assets/jquery/jquery.min.js"></script>
<script src="assets/popper/popper.min.js"></script>
<script src="assets/tether/tether.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/smoothscroll/smooth-scroll.js"></script>
<script src="assets/datatables/jquery.data-tables.min.js"></script>
<script src="assets/datatables/data-tables.bootstrap4.min.js"></script>
<script src="assets/theme/js/script.js"></script>


</body>
</html>