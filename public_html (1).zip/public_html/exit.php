<?php setcookie("ages", "", time() - 3600); 
include("login.html");?>