<body>
<?php
$link = mysqli_connect('localhost', 'id16122503_magnit', 'j6(o$Ny6R{+/HO|P', 'id16122503_workmen');

$Почта=$_REQUEST['first_name'];
$Телефон=trim($_REQUEST['last_name']);
$Пароль=trim($_REQUEST['email']);

mysqli_query($link,"UPDATE users SET Почта='$Почта', Телефон='$Телефон', Пароль='$Пароль' WHERE id ='".intval($_COOKIE['ages'])."'");

include("changeUSER.php");
?>
</body>
