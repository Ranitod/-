

<?php
   $links = mysqli_connect('localhost', 'id16122503_magnit', 'j6(o$Ny6R{+/HO|P', 'id16122503_workmen');
   $ids =$_REQUEST['id'];

  mysqli_query($links, "DELETE FROM users WHERE id = '$ids'");
  include("main.php");
  mysqli_close($links);
?>
