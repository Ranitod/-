<?PHP
function cleanData(&$str)
{
$str = preg_replace("/\t/", "\\t", $str);
$str = preg_replace("/\r?\n/", "\\n", $str);
if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
}
// Имя загружаемого файла.
//В моём примере получится otched_20150331.xls
$filename = "otchet_" . date('Ymd') . ".xls";

header("Content-Disposition: attachment; filename=\"$filename\"" );
header("Content-Type:   application/vnd.ms-excel; charset=utf-8");

// Подключение к бд
$link = mysqli_connect('localhost', 'id16122503_magnit', 'j6(o$Ny6R{+/HO|P', 'id16122503_workmen');
//Указать кодировку выводимых данных
mysqli_query($link,'SET character_set_database = utf8');
mysqli_query ($link,"SET NAMES 'utf8'");
//запрос и вывод данных
$query1 = mysqli_query($link, "SELECT * FROM users ");

$flag = false;
while($row=mysqli_fetch_assoc($query1)){
//Вывод данных столбцов
if(!$flag) {
// Вывод заголовков
echo implode("\t", array_keys($row)) . "\r\n";
$flag = true;
}
//Вывод данных столбцов
echo implode("\t", array_values($row)) . "\r\n";
}
exit;
?>