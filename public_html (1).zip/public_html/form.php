
<?php
$link = mysqli_connect('localhost', 'id16122503_magnit', 'j6(o$Ny6R{+/HO|P', 'id16122503_workmen');

$ФИО = $_REQUEST['ФИО'];
$Отдел = $_REQUEST['Отдел'];
$Должность = $_REQUEST['Должность'];
$Телефон = $_REQUEST['Телефон'];
$Почта = $_REQUEST['Почта'];
$Логин = $_REQUEST['Логин'];
$Пароль = $_REQUEST['Пароль'];
$Кто = $_REQUEST['Кто'];

mysqli_query($link, "INSERT INTO users (ФИО, Отдел, Должность, Телефон, Почта, Логин, Пароль, Кто)" .
"VALUES('$ФИО', '$Отдел', '$Должность', '$Телефон', '$Почта', '$Логин', '$Пароль', '$Кто')");


include("reg.html");
?>
