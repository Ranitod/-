<!DOCTYPE html>
<html >
 
  


<head>
    	<style type="text/css">
        #footer 
        {
          position: fixed; /* Фиксированное положение */
          center: 0; bottom: 0; /* Внизу центр */
          padding: 0px; /* Поля вокруг текста */
          background: #acacac; /* Цвет фона */
          color: #ffff; /* Цвет текста */
          width: 100%; /* Ширина слоя */
        }
	    </style>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.7.2, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/logo4.png" type="image/x-icon">
  <meta name="description" content="">
  <title>Home</title>
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/datatables/data-tables.bootstrap4.min.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">


  
  
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-light" style="background-color: #acacac;">
    <a class="navbar-brand" href="#"><img src="assets/images/logo.png" width="287" height="53.4"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item active">
          <a class="nav-link" href="main.php">Главная <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
            Личный кабинет
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <a class="dropdown-item" href="reg.html">Добавить пользователя</a>
            <a class="dropdown-item" href="change.php">Изменить данные</a>
            <a class="dropdown-item" href="excel.php">Экспорт в Excel</a>
            <a class="dropdown-item" href="exit.php">Выйти</a>
            </div>
        </li>
      </ul>
    </div>
  </nav>


  <section class="section-table cid-su1Ss3NIN9" id="table1-0">

  <div class="container container-table">
      <h2 class="mbr-section-title mbr-fonts-style align-center pb-3 display-2">&nbsp;</h2>
      <h3 class="mbr-section-subtitle mbr-fonts-style align-center pb-5 mbr-light display-5"></h3>
      <div class="table-wrapper">
        <div class="container">
          <div class="row search">
            <div class="col-md-6"></div>
            <div class="col-md-6">
                <div class="dataTables_filter">
                  <label class="searchInfo mbr-fonts-style display-7">Поиск:</label>
                  <input class="form-control input-sm" disabled="">
                </div>
            </div>
          </div>
        </div>

        <div class="container scroll">
          <table class="table isSearch" cellspacing="0">
            <thead>
              <tr class="table-heads ">
                  
                  
              <th class="head-item mbr-fonts-style display-7">
                      ФИО</th><th class="head-item mbr-fonts-style display-7">
                      ОТДЕЛ</th><th class="head-item mbr-fonts-style display-7">
                      ДОЛЖНОСТЬ</th><th class="head-item mbr-fonts-style display-7">
                      ТЕЛЕФОН</th><th class="head-item mbr-fonts-style display-7">
                      ПОЧТА</th><th class="head-item mbr-fonts-style display-7">
                      ЛОГИН</th><th class="head-item mbr-fonts-style display-7">
                      ПАРОЛЬ</th><th class="head-item mbr-fonts-style display-7">
                      РОЛЬ</th><th class="head-item mbr-fonts-style display-7">
                      ИЗМЕНЕНИЕ</th></tr>
                      
            </thead>
            <tbody>
              
              
              
              
            <?php  $link = mysqli_connect('localhost', 'id16122503_magnit', 'j6(o$Ny6R{+/HO|P', 'id16122503_workmen');
    
$query1 = mysqli_query($link, "SELECT * FROM users");

while($row=mysqli_fetch_array($query1))
{?>
            <tr>      
              <td class="body-item mbr-fonts-style display-7"><?php echo $row['ФИО']; ?></td>
                  <td class="body-item mbr-fonts-style display-7"> <?php echo $row['Отдел']; ?></td>
                  <td class="body-item mbr-fonts-style display-7"> <?php echo $row['Должность']; ?></td>
                  <td class="body-item mbr-fonts-style display-7"> <?php echo $row['Телефон']; ?></td>
                  <td class="body-item mbr-fonts-style display-7"> <?php echo $row['Почта']; ?></td>
                  <td class="body-item mbr-fonts-style display-7"> <?php echo $row['Логин']; ?></td>
                  <td class="body-item mbr-fonts-style display-7"> <?php echo $row['Пароль']; ?></td>
                  <td class="body-item mbr-fonts-style display-7"> <?php echo $row['Кто']; ?></td>
                  <td class="body-item mbr-fonts-style display-7">   <a href="changeALL.php?id=<?= $row['id'] ?>">ИЗМЕНИТЬ</a>
                  <a href="delet.php?id=<?= $row['id'] ?>">УДАЛИТЬ</a></td>
            </tr>
  <?php  } ?>             
                
            </table>
        </div>
        <div class="container table-info-container">
          <div class="row info">
            <div class="col-md-6">
              <div class="dataTables_info mbr-fonts-style display-7">
                <span class="infoBefore">Отражено</span>
                <span class="inactive infoRows"></span>
                <span class="infoAfter">записи</span>
                <span class="infoFilteredBefore">(фильтр на</span>
                <span class="inactive infoRows"></span>
                <span class="infoFilteredAfter"> записи)</span>
              </div>
            </div>
            <div class="col-md-6"></div>
          </div>
        </div>
      </div>
    </div>
</section>
	<div id="footer">
	<p align="center"> &copy; Официальный сайт сети «Магнит». АО «Тандер» </p>
	</div>

  <section class="engine"><a href="https://mobirise.me/p">website templates free download</a></section><script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/tether/tether.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/smoothscroll/smooth-scroll.js"></script>
  <script src="assets/datatables/jquery.data-tables.min.js"></script>
  <script src="assets/datatables/data-tables.bootstrap4.min.js"></script>
  <script src="assets/theme/js/script.js"></script>
  
  
</body>
</html>