<?php
$links = mysqli_connect('localhost', 'id16122503_magnit', 'j6(o$Ny6R{+/HO|P', 'id16122503_workmen');
$query2 = mysqli_query($links, "SELECT * FROM users WHERE id =' " . intval($_COOKIE['ages']) . " ' ");
$roee=mysqli_fetch_array($query2);
?>
<!DOCTYPE html>
<html >



<head>
<style type="text/css">
#footer
{
position: fixed; /* Фиксированное положение */
center: 0; bottom: 0; /* Внизу центр */
padding: 0px; /* Поля вокруг текста */
background: #acacac; /* Цвет фона */
color: #ffff; /* Цвет текста */
width: 100%; /* Ширина слоя */
}
</style>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="generator" content="Mobirise v4.7.2, mobirise.com">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
<link rel="shortcut icon" href="assets/images/logo4.png" type="image/x-icon">
<meta name="description" content="">
<title>Личный кабинет</title>
<link rel="stylesheet" href="assets/tether/tether.min.css">
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
<link rel="stylesheet" href="assets/datatables/data-tables.bootstrap4.min.css">
<link rel="stylesheet" href="assets/theme/css/style.css">
<link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">






</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light" style="background-color: #acacac;">
<a class="navbar-brand" href="#"><img src="assets/images/logo.png" width="287" height="53.4"></a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarNavDropdown">
<ul class="navbar-nav">
<li class="nav-item active">
<a class="nav-link" href="mainUSER.php">Главная <span class="sr-only">(current)</span></a>
</li>
<li class="nav-item dropdown">
<a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
Личный кабинет
</a>
<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">

<a class="dropdown-item" href="changeUSER.php">Изменить данные</a>
<a class="dropdown-item" href="exit.php">Выйти</a>
</div>
</li>
</ul>
</div>
</nav>
<?php
printf("<form action='updateUSER.php' method='post' name='forma'>
<fieldset>
<label for='first_name'>Почта:</label><br/>
<input type='text' name='first_name' size='30' value='%s'><br/>
<label for='last_name'>Телефон:</label><br/>
<input type='text' name='last_name' size='30' value='%s'><br/>
<label for='email'>Пароль:</label><br/>
<input type='text' name='email' size='30' value='%s'><br/>
</fieldset>
<br/>
<fieldset>
<input id='submit' type='submit' value='Редактировать запись'><br/>
</fieldset>
</form>",$roee['Почта'], $roee['Телефон'], $roee['Пароль']);
?>

<div id="footer">
<p align="center"> &copy; Официальный сайт сети «Магнит». АО «Тандер» </p>
</div>



<section class="engine"><a href="https://mobirise.me/p">website templates free download</a></section><script src="assets/web/assets/jquery/jquery.min.js"></script>
<script src="assets/popper/popper.min.js"></script>
<script src="assets/tether/tether.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/smoothscroll/smooth-scroll.js"></script>
<script src="assets/datatables/jquery.data-tables.min.js"></script>
<script src="assets/datatables/data-tables.bootstrap4.min.js"></script>
<script src="assets/theme/js/script.js"></script>


</body>
</html>