<?php
$Логин = filter_var(trim($_POST['Логин']), FILTER_SANITIZE_STRING);
$Пароль = filter_var(trim($_POST['Пароль']), FILTER_SANITIZE_STRING);
//$pass = md5($pass."forhktkntuhpi"); // Создаем хэш из пароля
$mysql = new mysqli('localhost', 'id16122503_magnit', 'j6(o$Ny6R{+/HO|P', 'id16122503_workmen');

$resultat = $mysql->query("SELECT * FROM `users` WHERE `Логин` = '$Логин' AND `Пароль` = '$Пароль' ");
$rows=mysqli_fetch_array($resultat);
if($rows['Логин'] != $Логин){
include("index.php");
}
else if($rows['Пароль']!= $Пароль){
include("index.php");
}
setcookie("ages", $rows['id'], time() + 3600);

$mysql->close();
if(($rows['Кто']) == "0"){header('Location: mainUSER.php');
}
else header('Location:main.php');
?>